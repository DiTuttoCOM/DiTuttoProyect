document.querySelectorAll('.menu-opciones li').forEach(item => {
  item.addEventListener('click', () => {
    // Cambiar clase active en menú
    document.querySelectorAll('.menu-opciones li').forEach(li => li.classList.remove('active'));
    item.classList.add('active');

    const section = item.getAttribute('data-section');
    const contenido = document.getElementById('contenido');

    switch(section) {
      case 'perfil':
        contenido.innerHTML = `<h2 id="bienvenida"></h2><p>Aquí podrás editar tu perfil, cambiar tu foto y actualizar tus datos personales.</p><button id="cerrarSesion" class="btn btn-danger mt-3">Cerrar sesión</button>`;
        break;
      case 'opciones':
        contenido.innerHTML = `<h2>Opciones</h2><p>Aquí puedes cambiar las opciones de tu cuenta.</p>`;
        break;
      case 'seguimientos':
        contenido.innerHTML = `<h2>Seguimientos</h2><p>Visualiza tus seguimientos aquí.</p>`;
        break;
      case 'transacciones':
        contenido.innerHTML = `<h2>Transacciones</h2><p>Consulta el historial de transacciones.</p>`;
        break;
      case 'seguridad':
        contenido.innerHTML = `<h2>Seguridad</h2><p>Configura la seguridad de tu cuenta.</p>`;
        break;
      default:
        contenido.innerHTML = `<h2>Perfil</h2><p>Aquí podrás editar tu perfil.</p>`;
    }
    // Si es perfil, vuelve a poner el saludo y botón de cerrar sesión
    if(section === 'perfil') {
      const usuario = JSON.parse(localStorage.getItem("usuario"));
      if (usuario && document.getElementById("bienvenida")) {
        document.getElementById("bienvenida").textContent = `¡Bienvenido, ${usuario.nombre}!`;
      }
      if (document.getElementById("cerrarSesion")) {
        document.getElementById("cerrarSesion").addEventListener("click", () => {
          localStorage.removeItem("usuario");
          location.href = "index.html";
        });
      }
    }
  });
});

// Mostrar saludo al cargar
window.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  if (usuario && document.getElementById("bienvenida")) {
    document.getElementById("bienvenida").textContent = `¡Bienvenido, ${usuario.nombre}!`;
  }
  if (document.getElementById("cerrarSesion")) {
    document.getElementById("cerrarSesion").addEventListener("click", () => {
      localStorage.removeItem("usuario");
      location.href = "index.html";
    });
  }
});
