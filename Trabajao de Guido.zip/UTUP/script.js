document.addEventListener("DOMContentLoaded", function() {
  const btnCuenta = document.getElementById('btnCuenta');
  if (btnCuenta) {
    btnCuenta.addEventListener('click', function() {
      window.location.href = "ajustes.html";
    });
  }

  // Hacer clic en el logo vuelve a la página principal
  const logoImg = document.querySelector('.logo img');
  if (logoImg) {
    logoImg.addEventListener('click', function() {
      window.location.href = "index.html";
    });
  }
});